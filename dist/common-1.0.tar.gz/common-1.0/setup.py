from setuptools import setup

setup(
    name='common',
    packages=['common'],
    description='Common libs',
    version='1.0',
    url='https://github.com/pasinter/test-lib/tree/master',
    author='pasinter',
    keywords=['common']
)
